<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary">Thống kê doanh thu 30 ngày gần nhất</h6>
	</div>
	<div class="card-body">
		<div class="chart-area">
			<div class="chartjs-size-monitor">
				<div class="chartjs-size-monitor-expand">
					<div class=""></div>
				</div>
				<div class="chartjs-size-monitor-shrink">
					<div class=""></div>
				</div>
			</div>
			<canvas id="myAreaChart" style="display: block; height: 320px; width: 371px;" width="408" height="352" class="chartjs-render-monitor"></canvas>
		</div>
		<hr>
	</div>
</div>
