 <!-- cuoi -->
 <hr width="80%" style="margin: auto; " height="30px">

 <div class="footer">
 	<div class="grid_full-width">
 		<div class="grid">
 			<div class="row">
 				<div class="col col-4 col-mobi">
 					<div class="logo logo-bottom ml-mobi">
 						<img height="100%" src="./public/img/logo1-2.png" alt="" class="img">
 					</div>
 					<div class="footer__text ml-mobi">
 						<p>Khánh Duy Mobile thành lập năm 2025. Chúng
 							tôi chuyên bán điện thoại xách tay cao cấp.</p>
 					</div>
 				</div>
 				<div class="col col-4 col-mobi">
 					<div class="footer__about">
 						<h3>Địa chỉ</h3>
 					</div>
 					<div class="footer__text">
 						<a href="https://maps.app.goo.gl/166vevaGWxz9Fuze9">193 Đỗ Văn Thi, Phường, Thành phố Biên Hòa, Đồng Nai
 							700000, Việt Nam</a>
 					</div>
 				</div>
 				<div class="col col-4 col-mobi">
 					<div class="footer__about">
 						<h3>Dịch vụ</h3>
 					</div>
 					<div class="footer__text">
 						<p>
 							Bảo hành rơi vỡ, ngấm nước Care Diamond
 						</p>
 						<p>
 							Bảo hành Care X60 rơi vỡ ngấm nước vẫn Đổi
 							mới
 						</p>
 					</div>
 				</div>
 				<div class="col col-4 col-mobi">
 					<div class="footer__about">
 						<h3>Liên hệ</h3>
 					</div>
 					<div class="footer__text">
 						<p>Phone Sale: <a href="tel:+84 399902410">(+84) 039 990 2410</a></p>
 						<p>Email: <a href="mailto:dynguyenak@gmail.com">dynguyenak@gmail.com</a></p>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </div>
 <div class="header">
 	<div class="header-container">
 		<header class="header-bottom">
 			<span>2024 ©
 			</span>
 		</header>
 	</div>
 </div>
